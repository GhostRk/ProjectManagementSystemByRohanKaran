import graphene
from graphene_django import DjangoObjectType
from .models import Organization, Project, Task, TaskComment

# ------------------
# GraphQL Types
# ------------------

class OrganizationType(DjangoObjectType):
    class Meta:
        model = Organization
        fields = ("id", "name", "slug", "contact_email", "project_set")


class ProjectType(DjangoObjectType):
    class Meta:
        model = Project
        fields = ("id", "name", "status", "description", "due_date", "organization", "task_set")


class TaskType(DjangoObjectType):
    class Meta:
        model = Task
        fields = ("id", "title", "description", "status", "assignee_email", "project", "taskcomment_set")


class TaskCommentType(DjangoObjectType):
    class Meta:
        model = TaskComment
        fields = ("id", "content", "author_email", "timestamp", "task")

# ------------------
# Queries
# ------------------

class Query(graphene.ObjectType):
    organizations = graphene.List(OrganizationType)
    projects = graphene.List(ProjectType)
    tasks = graphene.List(TaskType)
    task_comments = graphene.List(TaskCommentType)

    def resolve_organizations(root, info):
        return Organization.objects.all()

    def resolve_projects(root, info):
        return Project.objects.all()

    def resolve_tasks(root, info):
        return Task.objects.all()

    def resolve_task_comments(root, info):
        return TaskComment.objects.all()

# ------------------
# Mutations
# ------------------

class CreateTask(graphene.Mutation):
    task = graphene.Field(TaskType)

    class Arguments:
        project_id = graphene.ID(required=True)
        title = graphene.String(required=True)
        description = graphene.String()
        status = graphene.String()
        assignee_email = graphene.String()

    def mutate(self, info, project_id, title, description=None, status="PENDING", assignee_email=None):
        project = Project.objects.get(pk=project_id)
        task = Task.objects.create(
            project=project,
            title=title,
            description=description,
            status=status,
            assignee_email=assignee_email
        )
        return CreateTask(task=task)


class AddTaskComment(graphene.Mutation):
    comment = graphene.Field(TaskCommentType)

    class Arguments:
        task_id = graphene.ID(required=True)
        content = graphene.String(required=True)
        author_email = graphene.String(required=True)

    def mutate(self, info, task_id, content, author_email):
        task = Task.objects.get(pk=task_id)
        comment = TaskComment.objects.create(
            task=task,
            content=content,
            author_email=author_email
        )
        return AddTaskComment(comment=comment)

class Mutation(graphene.ObjectType):
    create_task = CreateTask.Field()
    add_task_comment = AddTaskComment.Field()


# Final schema
schema = graphene.Schema(query=Query, mutation=Mutation)
