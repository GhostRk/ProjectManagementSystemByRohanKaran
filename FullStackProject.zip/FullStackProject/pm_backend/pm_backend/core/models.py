from django.db import models


class Organization(models.Model):
    """
    Tenant-level entity. All other data hangs off an organization.
    """
    name = models.CharField(max_length=100)
    slug = models.SlugField(max_length=100, unique=True)  # used for multi-tenancy scoping
    contact_email = models.EmailField()

    def __str__(self):
        return f"{self.name} ({self.slug})"


class Project(models.Model):
    STATUS_CHOICES = [
        ("ACTIVE", "Active"),
        ("COMPLETED", "Completed"),
        ("ON_HOLD", "On Hold"),
        ("PENDING", "Pending"),
         
    ]

    organization = models.ForeignKey(
        Organization,
        on_delete=models.CASCADE,
        related_name="projects",
    )
    name = models.CharField(max_length=200)
    description = models.TextField(blank=True)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default="ACTIVE")
    due_date = models.DateField(null=True, blank=True)

    def __str__(self):
        return f"{self.name} [{self.organization.slug}]"


class Task(models.Model):
    TASK_STATUS_CHOICES = [
        ("TODO", "To Do"),
        ("IN_PROGRESS", "In Progress"),
        ("DONE", "Done"),
        ("PENDING", "Pending")
    ]

    project = models.ForeignKey(
        Project,
        on_delete=models.CASCADE,
        related_name="tasks",
    )
    title = models.CharField(max_length=200)
    description = models.TextField(blank=True)
    status = models.CharField(max_length=20, choices=TASK_STATUS_CHOICES, default="TODO")
    assignee_email = models.EmailField(blank=True)

    def __str__(self):
        return f"{self.title} -> {self.project.name}"


class TaskComment(models.Model):
    task = models.ForeignKey(
        Task,
        on_delete=models.CASCADE,
        related_name="comments",
    )
    content = models.TextField()
    author_email = models.EmailField()
    timestamp = models.DateTimeField(auto_now_add=True)  # created time

    def __str__(self):
        return f"Comment by {self.author_email} on {self.task}"
