import { useParams, Link } from "react-router-dom";
import { useQuery } from "@apollo/client";
import { GET_TASKS } from "../graphql/queries";
import type { Task, Comment } from "../types";
import AddCommentForm from "../ui/AddCommentForm";

export default function TaskDetailsPage() {
  const { id } = useParams();
  const { data, loading, error } = useQuery<{ tasks: Task[] }>(GET_TASKS);

  if (loading) return <div>Loading…</div>;
  if (error) return <div className="text-red-600">Error: {error.message}</div>;

  const task = data?.tasks?.find((t) => t.id === id);
  if (!task) return (
    <div>
      <p className="mb-4">Task not found.</p>
      <Link to="/tasks" className="underline">Back to Tasks</Link>
    </div>
  );

  return (
    <div className="grid md:grid-cols-3 gap-6">
      <div className="md:col-span-2 space-y-4">
        <div className="rounded-2xl border bg-white p-4 shadow-sm">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-semibold">{task.title}</h2>
            <span className="text-xs px-2 py-1 rounded-full border">{task.status}</span>
          </div>
          <p className="text-sm text-gray-600 mt-1">Project: {task.project?.name ?? "—"}</p>
          {task.assigneeEmail && <p className="text-sm text-gray-600 mt-1">Assignee: {task.assigneeEmail}</p>}
          {task.description && <p className="text-sm text-gray-700 mt-3">{task.description}</p>}
        </div>

        <div className="rounded-2xl border bg-white p-4 shadow-sm">
          <h3 className="font-semibold mb-2">Comments</h3>
          <div className="space-y-3">
            {(task.comments ?? []).length === 0 && <p className="text-sm text-gray-500">No comments yet.</p>}
            {(task.comments ?? []).map((c: Comment) => (
              <div key={c.id} className="rounded-xl border p-3">
                <p className="text-sm">{c.content}</p>
                <p className="text-xs text-gray-500 mt-1">
                  {c.authorEmail} • {new Date(c.timestamp).toLocaleString()}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div>
        <AddCommentForm taskId={task.id} />
        <div className="mt-4"><Link to="/tasks" className="underline">← Back to Tasks</Link></div>
      </div>
    </div>
  );
}
