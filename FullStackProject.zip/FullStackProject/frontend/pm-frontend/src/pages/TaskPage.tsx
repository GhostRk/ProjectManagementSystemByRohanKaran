import { useQuery } from "@apollo/client";
import { GET_TASKS } from "../graphql/queries";
import type { Task } from "../types";
import NewTaskForm from "../ui/NewTaskForm";
import { Link } from "react-router-dom";

export default function TasksPage() {
  const { data, loading, error } = useQuery<{ tasks: Task[] }>(GET_TASKS);

  return (
    <div className="space-y-6">
      <div className="rounded-2xl border bg-white p-4 shadow-sm">
        <h2 className="text-xl font-semibold mb-2">Create Task</h2>
        <NewTaskForm />
      </div>

      <div>
        <h2 className="text-2xl font-semibold mb-4">Tasks</h2>
        {loading && <div>Loading tasks…</div>}
        {error && <div className="text-red-600">Error: {error.message}</div>}

        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {data?.tasks?.map((t) => (
            <Link
              key={t.id}
              to={`/tasks/${t.id}`}
              className="rounded-2xl border bg-white p-4 shadow-sm hover:shadow transition"
            >
              <div className="flex items-center justify-between">
                <h3 className="font-semibold">{t.title}</h3>
                <span className="text-xs px-2 py-1 rounded-full border">{t.status}</span>
              </div>
              <p className="text-sm text-gray-600 mt-2">Project: {t.project?.name ?? "—"}</p>
              {t.assigneeEmail && <p className="text-sm text-gray-600 mt-1">Assignee: {t.assigneeEmail}</p>}
              {t.description && <p className="text-sm text-gray-600 mt-1 line-clamp-2">{t.description}</p>}
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
}
