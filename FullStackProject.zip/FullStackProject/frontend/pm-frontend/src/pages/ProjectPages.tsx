import { gql, useQuery } from "@apollo/client";

const GET_PROJECTS = gql`
  query GetProjects {
    projects {
      id
      name
      status
      organization {
        id
        name
      }
    }
  }
`;

function ProjectsPage() {
  const { data, loading, error } = useQuery(GET_PROJECTS);

  if (loading) return <p>Loading projects...</p>;
  if (error) return <p>Error: {error.message}</p>;

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-4">Projects</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {data.projects.map((project: any) => (
          <div
            key={project.id}
            className="p-4 rounded shadow bg-white border"
          >
            <h2 className="font-semibold text-lg">{project.name}</h2>
            <p className="text-sm text-gray-500">Status: {project.status}</p>
            <p className="text-sm text-gray-600">
              Organization: {project.organization?.name}
            </p>
          </div>
        ))}
      </div>
    </div>
  );
}

export default ProjectsPage;  // ✅ default export
