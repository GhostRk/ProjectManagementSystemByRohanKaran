export type Organization = {
  id: string;
  name: string;
  slug?: string;
  contactEmail?: string;
};

export type Project = {
  id: string;
  name: string;
  description?: string;
  status: "ACTIVE" | "COMPLETED" | "ON_HOLD";
  dueDate?: string;
  organization: Pick<Organization, "id" | "name">;
};

export type Comment = {
  id: string;
  content: string;
  authorEmail: string;
  timestamp: string;
};

export type Task = {
  id: string;
  title: string;
  description?: string;
  status: "TODO" | "IN_PROGRESS" | "DONE";
  assigneeEmail?: string;
  dueDate?: string;
  project: { id: string; name: string };
  comments?: Comment[];
};
