import { gql } from "@apollo/client";

export const GET_PROJECTS = gql`
  query GetProjects {
    projects {
      id
      name
      description
      status
      dueDate
      organization { id name }
    }
  }
`;

export const GET_TASKS = gql`
  query GetTasks {
    tasks {
      id
      title
      description
      status
      assigneeEmail
      project { id name }
      comments {
        id
        content
        authorEmail
        timestamp
      }
    }
  }
`;

// Optional: if you add a single-task query in backend later
export const GET_TASK = gql`
  query GetTask($id: ID!) {
    task(id: $id) {
      id
      title
      description
      status
      assigneeEmail
      project { id name }
      comments { id content authorEmail timestamp }
    }
  }
`;
