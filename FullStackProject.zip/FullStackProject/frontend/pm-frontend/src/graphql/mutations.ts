import { gql } from "@apollo/client";

// if you add these on the backend (snippet below), these will work:
export const CREATE_PROJECT = gql`
  mutation CreateProject(
    $organizationId: ID!,
    $name: String!,
    $description: String,
    $status: String!,
    $dueDate: Date
  ) {
    createProject(
      organizationId: $organizationId,
      name: $name,
      description: $description,
      status: $status,
      dueDate: $dueDate
    ) {
      project { id name description status dueDate organization { id name } }
    }
  }
`;

export const UPDATE_PROJECT = gql`
  mutation UpdateProject(
    $id: ID!,
    $name: String,
    $description: String,
    $status: String,
    $dueDate: Date
  ) {
    updateProject(
      id: $id,
      name: $name,
      description: $description,
      status: $status,
      dueDate: $dueDate
    ) {
      project { id name description status dueDate organization { id name } }
    }
  }
`;

export const CREATE_TASK = gql`
  mutation CreateTask(
    $projectId: ID!,
    $title: String!,
    $status: String!,
    $description: String,
    $assigneeEmail: String
  ) {
    createTask(
      projectId: $projectId,
      title: $title,
      status: $status,
      description: $description,
      assigneeEmail: $assigneeEmail
    ) {
      task {
        id
        title
        status
        description
        assigneeEmail
        project { id name }
        comments { id content authorEmail timestamp }
      }
    }
  }
`;

export const ADD_TASK_COMMENT = gql`
  mutation AddTaskComment($taskId: ID!, $content: String!, $authorEmail: String!) {
    addTaskComment(taskId: $taskId, content: $content, authorEmail: $authorEmail) {
      comment {
        id
        content
        authorEmail
        timestamp
        task { id }
      }
    }
  }
`;
