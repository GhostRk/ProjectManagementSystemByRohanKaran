import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";
import ProjectsPage from "./pages/ProjectPages";
import TasksPage from "./pages/TaskPage";

function App() {
  return (
    <Router>
      <div className="min-h-screen bg-gray-900 text-white">
        {/* Navbar */}
        <nav className="bg-gray-800 shadow p-4 flex gap-6">
          <Link to="/" className="text-lg font-semibold hover:text-blue-400">Home</Link>
          <Link to="/projects" className="text-lg font-semibold hover:text-blue-400">Projects</Link>
          <Link to="/tasks" className="text-lg font-semibold hover:text-blue-400">Tasks</Link>
        </nav>

        {/* Content */}
        <div className="p-6">
          <Routes>
            <Route path="/" element={<h1 className="text-3xl font-bold">Welcome to Project Management</h1>} />
            <Route path="/projects" element={<ProjectsPage />} />
            <Route path="/tasks" element={<TasksPage />} />
          </Routes>
        </div>
      </div>
    </Router>
  );
}

export default App;
