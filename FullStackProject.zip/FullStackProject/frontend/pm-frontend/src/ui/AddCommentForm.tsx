import { useMutation } from "@apollo/client";
import { useForm } from "react-hook-form";
import { ADD_TASK_COMMENT } from "../graphql/mutations";

type Props = { taskId: string };
type FormValues = { authorEmail: string; content: string };

export default function AddCommentForm({ taskId }: Props) {
  const { register, handleSubmit, reset } = useForm<FormValues>();

  const [addComment, { loading, error }] = useMutation(ADD_TASK_COMMENT, {
    optimisticResponse: (vars) => ({
      addTaskComment: {
        __typename: "AddTaskComment",
        comment: {
          __typename: "TaskCommentType",
          id: Math.random().toString(),
          content: vars.content,
          authorEmail: vars.authorEmail,
          timestamp: new Date().toISOString(),
          task: { __typename: "TaskType", id: taskId },
        },
      },
    }),
    update(cache, { data }) {
      const newComment = data?.addTaskComment?.comment;
      if (!newComment) return;

      // Append to the task’s comments in cache
      cache.modify({
        id: cache.identify({ __typename: "TaskType", id: taskId }),
        fields: {
          comments(existingRefs = []) {
            const newRef = cache.writeFragment({
              data: newComment,
              fragment: /* GraphQL */ `
                fragment NewComment on TaskCommentType {
                  id
                  content
                  authorEmail
                  timestamp
                }
              `,
            });
            return [...existingRefs, newRef];
          }
        }
      });
    },
  });

  const onSubmit = async (vals: FormValues) => {
    await addComment({ variables: { taskId, ...vals } });
    reset({ authorEmail: "", content: "" });
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="rounded-2xl border bg-white p-4 shadow-sm space-y-2">
      <h4 className="font-semibold">Add Comment</h4>
      <label className="text-sm block">
        Your Email
        <input className="mt-1 w-full rounded border px-3 py-2" type="email" required {...register("authorEmail")} />
      </label>
      <label className="text-sm block">
        Comment
        <textarea className="mt-1 w-full rounded border px-3 py-2" rows={3} required {...register("content")} />
      </label>
      {error && <div className="text-sm text-red-600">Error: {error.message}</div>}
      <button type="submit" disabled={loading} className="rounded-xl border px-4 py-2 shadow-sm disabled:opacity-50 active:scale-95 transition">
        {loading ? "Posting…" : "Post Comment"}
      </button>
    </form>
  );
}
