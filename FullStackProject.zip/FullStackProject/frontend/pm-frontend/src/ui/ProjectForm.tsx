import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";

const schema = z.object({
  organizationId: z.string().min(1, "Organization is required"),
  name: z.string().min(2, "Name is too short"),
  description: z.string().optional(),
  status: z.enum(["ACTIVE", "COMPLETED", "ON_HOLD"]),
  dueDate: z.string().optional(), // yyyy-mm-dd
});

type FormValues = z.infer<typeof schema>;

export default function ProjectForm({
  initial,
  onSubmit,
  submitLabel = "Submit",
}: {
  initial?: Partial<FormValues>;
  onSubmit: (values: FormValues) => Promise<void> | void;
  submitLabel?: string;
}) {
  const { register, handleSubmit, formState: { errors, isSubmitting } } = useForm<FormValues>({
    resolver: zodResolver(schema),
    defaultValues: { status: "ACTIVE", ...initial },
  });

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="grid gap-3">
      {/* Org select: in a full app you’d query organizations; here we keep it simple */}
      <label className="text-sm">
        Organization ID
        <input className="mt-1 w-full rounded border px-3 py-2" {...register("organizationId")} placeholder="1" />
        {errors.organizationId && <p className="text-xs text-red-600">{errors.organizationId.message}</p>}
      </label>

      <label className="text-sm">
        Name
        <input className="mt-1 w-full rounded border px-3 py-2" {...register("name")} placeholder="Website Revamp" />
        {errors.name && <p className="text-xs text-red-600">{errors.name.message}</p>}
      </label>

      <label className="text-sm">
        Description
        <textarea className="mt-1 w-full rounded border px-3 py-2" rows={3} {...register("description")} />
      </label>

      <div className="grid sm:grid-cols-2 gap-3">
        <label className="text-sm">
          Status
          <select className="mt-1 w-full rounded border px-3 py-2" {...register("status")}>
            <option value="ACTIVE">ACTIVE</option>
            <option value="COMPLETED">COMPLETED</option>
            <option value="ON_HOLD">ON_HOLD</option>
          </select>
        </label>
        <label className="text-sm">
          Due Date
          <input type="date" className="mt-1 w-full rounded border px-3 py-2" {...register("dueDate")} />
        </label>
      </div>

      <button
        type="submit"
        disabled={isSubmitting}
        className="mt-2 rounded-xl border px-4 py-2 shadow-sm disabled:opacity-50 transition active:scale-95"
      >
        {isSubmitting ? "Saving…" : submitLabel}
      </button>
    </form>
  );
}
