import { useMutation, useQuery } from "@apollo/client";
import { useForm } from "react-hook-form";
import { GET_PROJECTS, GET_TASKS } from "../graphql/queries";
import { CREATE_TASK } from "../graphql/mutations";

type FormValues = {
  projectId: string;
  title: string;
  status: "TODO" | "IN_PROGRESS" | "DONE";
  description?: string;
  assigneeEmail?: string;
};

type ProjectOption = { id: string; name: string };

export default function NewTaskForm() {
  const { data: projData } = useQuery<{ projects: ProjectOption[] }>(GET_PROJECTS);
  const { register, handleSubmit, reset } = useForm<FormValues>({
    defaultValues: { status: "TODO" }
  });

  const [createTask, { loading, error }] = useMutation(CREATE_TASK, {
    // Optimistic task creation
    optimisticResponse: (vars) => ({
      createTask: {
        __typename: "CreateTask",
        task: {
          __typename: "TaskType",
          id: Math.random().toString(),
          title: vars.title,
          status: vars.status,
          description: vars.description ?? "",
          assigneeEmail: vars.assigneeEmail ?? "",
          project: {
            __typename: "ProjectType",
            id: vars.projectId,
            name: projData?.projects?.find(p => p.id === vars.projectId)?.name ?? "",
          },
          comments: [],
        },
      },
    }),
    update(cache, { data }) {
      const newTask = data?.createTask?.task;
      if (!newTask) return;
      cache.modify({
        fields: {
          tasks(existingRefs = []) {
            const newRef = cache.writeFragment({
              data: newTask,
              fragment: /* GraphQL */ `
                fragment NewTask on TaskType {
                  id
                  title
                  status
                  description
                  assigneeEmail
                  project { id name }
                  comments { id content authorEmail timestamp }
                }
              `,
            });
            return [newRef, ...existingRefs];
          }
        }
      });
    },
  });

  const onSubmit = async (vals: FormValues) => {
    await createTask({ variables: vals });
    reset({ title: "", description: "", assigneeEmail: "", projectId: "", status: "TODO" });
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="grid gap-3">
      <div className="grid sm:grid-cols-2 gap-3">
        <label className="text-sm">
          Project
          <select className="mt-1 w-full rounded border px-3 py-2" {...register("projectId")} required>
            <option value="">Select a project…</option>
            {projData?.projects?.map((p) => (
              <option key={p.id} value={p.id}>{p.name}</option>
            ))}
          </select>
        </label>
        <label className="text-sm">
          Status
          <select className="mt-1 w-full rounded border px-3 py-2" {...register("status")}>
            <option value="TODO">TODO</option>
            <option value="IN_PROGRESS">IN_PROGRESS</option>
            <option value="DONE">DONE</option>
          </select>
        </label>
      </div>

      <label className="text-sm">
        Title
        <input className="mt-1 w-full rounded border px-3 py-2" {...register("title", { required: true })} />
      </label>

      <label className="text-sm">
        Description
        <textarea className="mt-1 w-full rounded border px-3 py-2" rows={3} {...register("description")} />
      </label>

      <label className="text-sm">
        Assignee Email
        <input className="mt-1 w-full rounded border px-3 py-2" {...register("assigneeEmail")} type="email" />
      </label>

      {error && <div className="text-sm text-red-600">Error: {error.message}</div>}

      <button type="submit" disabled={loading} className="rounded-xl border px-4 py-2 shadow-sm disabled:opacity-50 active:scale-95 transition">
        {loading ? "Creating…" : "Create Task"}
      </button>
    </form>
  );
}
